"""
Brain Tumor CDSS - 더미 데이터 설정 패키지

사용법:
    python -m setup_dummy_data          # 전체 실행
    python -m setup_dummy_data --reset  # 리셋 후 재생성
    python -m setup_dummy_data --base   # 기본 데이터만
    python -m setup_dummy_data --add    # 추가 데이터만
"""
