"""
패키지 진입점: python -m setup_dummy_data
"""
from .main import main

if __name__ == '__main__':
    main()
